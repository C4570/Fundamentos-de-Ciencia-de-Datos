Este dataset fue descargado de datos.gob.ar

https://www.datos.gob.ar/dataset/mincyt-personal-ciencia-tecnologia

La información sobre las variables de este recurso se encuentran descritas en 
https://www.datos.gob.ar/dataset/mincyt-personal-ciencia-tecnologia/archivo/mincyt_5743ab23-022b-482a-a50a-afd547518ad3
