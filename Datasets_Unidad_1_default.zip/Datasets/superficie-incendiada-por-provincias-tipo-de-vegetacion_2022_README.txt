Este dataset fue descargado de datos.gob.ar

https://www.datos.gob.ar/dataset/ambiente-incendios-forestales

La información sobre las variables de este recurso se encuentran descritas en https://www.datos.gob.ar/dataset/ambiente-incendios-forestales/archivo/ambiente_c7b70f96-5562-4673-9b61-6ead123a99f7


