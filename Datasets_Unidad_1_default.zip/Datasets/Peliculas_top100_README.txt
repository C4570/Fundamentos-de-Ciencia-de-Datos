About Dataset
The dataset contains most 100 popular movies for each year in the interval 2003-2022.
The Data is Ideal for Exploratory Data Analysis.
Every single information has been collected by web scraping and can be found on iMDB.

The dataset contains:

Title
Rating
Year
Month
Certificate
Runtime
Director/s
Stars
Genre/s
Filming Location
Budget
Income
Country of Origin